
package com.mycompany.ejerciciosbasicos;

import java.util.Scanner;

public class ejercicio1 {
  
        public static void main(String[] args) {
        String nombre;
        Scanner lectura = new Scanner(System.in);   
            
            
        System.out.println("----------------------------------------------------");
        System.out.println("Ingrese su nombre:");
        nombre=lectura.nextLine();
        System.out.println("Hola "+nombre);
    
}
}
